/*

1. 프로젝트 패키지 -> bin 폴더

2.
  (1) 컴파일 : javac HelloWorld.java
  (2) 실행 : java HelloWorld


 */