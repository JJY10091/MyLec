use koreaitdb;

create table users(
email varchar(50),
passwd varchar(20)
);