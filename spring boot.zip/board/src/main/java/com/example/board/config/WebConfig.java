package com.example.board.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        //보안해지폴더등록 : 접근허용
        //핸들러 webconfig 파일이 존재하면 아래 폴더에 있는 파일들이 자동으로 새로고침이됨
        registry.addResourceHandler("/**")
                .addResourceLocations("file:src/main/resources/static/upload/")
                .addResourceLocations("file:///D:/temp/");   //외부 드라이버는 ///로 인식됨
    }
}
