package com.example.tut05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tut05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
