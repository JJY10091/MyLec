package com.example.tut03.dto;


import lombok.Data;

@Data
public class RegDto {
    private String email;
    private String passwd;



}
